# accounts/tests/__init__.py
# This ensures that tests is treated as a package.
